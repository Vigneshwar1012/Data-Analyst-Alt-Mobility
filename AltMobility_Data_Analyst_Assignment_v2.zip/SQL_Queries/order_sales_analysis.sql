
-- 1. Order and Sales Analysis
SELECT 
    order_status,
    COUNT(order_id) AS total_orders,
    SUM(order_amount) AS total_revenue
FROM 
    customer_orders
GROUP BY 
    order_status
ORDER BY 
    total_orders DESC;
