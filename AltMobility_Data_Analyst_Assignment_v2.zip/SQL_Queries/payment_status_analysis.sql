
-- 3. Payment Status Analysis
SELECT 
    payment_status,
    COUNT(payment_id) AS count,
    SUM(payment_amount) AS total_payment
FROM 
    payments
GROUP BY 
    payment_status
ORDER BY 
    count DESC;
