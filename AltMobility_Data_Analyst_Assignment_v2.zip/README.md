
# Alt Mobility - Data Analyst Internship Assignment

## Project Overview
This repository contains the solutions for the Alt Mobility Data Analyst Internship Assignment.

## Structure
- **SQL_Queries**: SQL queries for analysis and reporting.
- **Visualizations**: Customer retention chart and explanation.
- **Summary_of_Findings**: Key insights and recommendations.

## Approach

1. **Order and Sales Analysis**: Analyzed order statuses and revenue trends.
2. **Customer Analysis**: Studied repeat ordering behavior and segmented customers.
3. **Payment Status Analysis**: Investigated payment success and failures.
4. **Order Report**: Combined order and payment details for comprehensive reporting.
5. **Retention Analysis**: Visualized cohort retention trends using BI tools.

## Tech Stack
- SQL
- Power BI / Tableau (for visualization)
- GitHub (for submission)

## Author
[Your Name]
